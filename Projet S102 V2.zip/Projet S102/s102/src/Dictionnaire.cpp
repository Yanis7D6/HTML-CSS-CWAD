#include <SDL_image.h>
#include <exception>
#include <string>
#include "Image.h"
#include "Moteur.h"
#include "Tuile.h"
#include "Dictionnaire.h"
#include <fstream>
#include <stdexcept>

using namespace std;

Dictionnaire::Dictionnaire() {}

Dictionnaire::Dictionnaire(const string& nomFic)
{
    ifstream entree(nomFic);
    if (!entree) {
        throw runtime_error("Impossible d'ouvrir le fichier : " + nomFic);
    }

    string nom, propriete;
    int x, y, nbT;

    entree >> nbT; // Lire le nombre de tuiles
    for (int i = 0; i < nbT; ++i) {
        entree >> nom >> x >> y >> propriete;
        if (entree) { // V�rifier que la ligne a bien �t� lue
            Tuile t(nom, x, y, propriete);
            _tuiles.push_back(t); // Ajouter l'objet � la liste
        } else {
            throw runtime_error("Erreur lors de la lecture des donn�es du fichier.");
        }
    }

    entree.close();
}


void Dictionnaire::afficher() const
{
    for (int i = 0; i < _tuiles.size(); i++)
        _tuiles[i].afficher();
}

bool Dictionnaire::recherche(const string& nomTuile, Tuile& tuileTrouvee) const
{
    int debut = 0;
    int fin = _tuiles.size() - 1;
    int milieu;

    while (debut <= fin)
    {
        milieu = (debut + fin) / 2;

        if (nomTuile == _tuiles[milieu].getNom())
        {
            tuileTrouvee = _tuiles[milieu]; // Renvoie l'objet trouv�
            return true;
        }
        else if (nomTuile < _tuiles[milieu].getNom())
        {
            fin = milieu - 1; // Aller "� gauche"
        }
        else
        {
            debut = milieu + 1; // Aller "� droite"
        }
    }

    return false; // L'�l�ment n'a pas �t� trouv�
}
