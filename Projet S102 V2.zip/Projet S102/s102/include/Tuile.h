#ifndef TUILE_H_INCLUDED
#define TUILE_H_INCLUDED
#include <SDL_image.h>
#include "Moteur.h"
#include <iostream>
#include <string>

using namespace std;

class Tuile
{
    string _nom; // Le nom de la tuile
    int _skin_x, _skin_y; // Les coordonn�es (x, y) du skin de la tuile
    string _propriete; // La propri�t� de la tuile
public:
    // Constructeur vide
    Tuile();

    // Constructeur
    Tuile(string& nom, int skin_x, int skin_y, string& propriete);

    // Affichage de la tuile
    void afficher() const;

    // Retourne le nom
    string getNom() const;

    // Retourne la coordonn�e x du skin
    int getSkinX() const;

    // Retourne la coordonn�e y du skin
    int getSkinY() const;

    // Retourne la propri�t�
    string getPropiete() const;
};

#endif // TUILE_H_INCLUDED
