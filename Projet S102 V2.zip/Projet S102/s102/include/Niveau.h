#ifndef NIVEAU_H_INCLUDED
#define NIVEAU_H_INCLUDED
#include <SDL_image.h>
#include "Moteur.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Niveau
{
    vector<Objet> _objets; // Les objets du niveau
    int _nbBonus; // Le nombre de bonus du niveau

public:
    // Constructeur vide
    Niveau();

    // Constructeur
    Niveau(Image& img, const string& nomFic, const Dictionnaire& dico);

    // Dessine les objets du niveau
    void dessiner() const;

    // V�rifie si la case est libre
    bool caseEstLibre(int x, int y) const;

    // V�rifie si la case contient un bonus et le prendre si c'est le cas
    void testerBonusEtPrendre(int x, int y);

    /* V�rifie si un objet a la propri�t� pris en param�tre puis si les coordonn�es x et y pris en param�tre sont
    �gales a celui de l'objet */
    int indiceObjet(int x, int y, const string& propriete) const;

    // V�rifie si le joueur a gagn� en collectant tout les bonus du niveau
    bool gagne() const;

    // Retourne le nombre de bonus restants dans le niveau
    int getNbBonus() const;
};

#endif // NIVEAU_H_INCLUDED
