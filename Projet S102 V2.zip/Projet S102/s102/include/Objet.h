#ifndef OBJET_H_INCLUDED
#define OBJET_H_INCLUDED
#include <SDL_image.h>
#include "Moteur.h"
#include <iostream>
#include <string>

using namespace std;

class Objet
{
    Image _image; // L'image de l'objet
    int _x, _y; // Les coordonn�es (x, y) de l'objet
    string _propriete; // La propri�t� de l'objet
public:
    // Constructeur vide
    Objet();

    // Constructeur
    Objet(Image& img, string& nomObjet, const Dictionnaire& dico, int x, int y);

    // Dessine l'objet
    void dessiner() const;

    // Retourne la coordonn�e x
    int getX() const;

    // Retourne la coordonn�e y
    int getY() const;

    // Retourne la propri�t�
    string getPropiete() const;

    // Modifie directement la propri�t� de l'objet pour la marquer comme "cache"
    void cache();
};

#endif // OBJET_H_INCLUDED
